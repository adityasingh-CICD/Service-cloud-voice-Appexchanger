exports.handler = async (event) => {
  const AWS = require('aws-sdk');
  const connect = new AWS.Connect();
  const instanceId = process.env.INSTANCE_ID; // Ensure this env variable is set in Lambda configuration

  // Parse the body
  let body = event;
  if (typeof event.body === 'string') {
    try {
      body = JSON.parse(event.body);
    } catch (e) {
      console.error('Failed to parse body:', e);
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid JSON body' }),
      };
    }
  }

  // --- DELETE QUEUE ---
  if (body.action === 'delete' && body.queueId) {
    try {
      await connect.deleteQueue({
        InstanceId: instanceId,
        QueueId: body.queueId
      }).promise();
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Queue deleted successfully' })
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message })
      };
    }
  }

  // --- UPDATE QUEUE ---
  if (body.action === 'update' && body.queueId) {
    const queueId = body.queueId;
    const updateResponses = [];

    try {
      // Update name/description
      if (body.name || body.description) {
        const params = {
          InstanceId: instanceId,
          QueueId: queueId,
          Name: body.name,
          Description: body.description
        };
        await connect.updateQueueName(params).promise();
        updateResponses.push('Name/Description updated');
      }

      // Update hours of operation
      if (body.hoursOfOperationId) {
        const params = {
          InstanceId: instanceId,
          QueueId: queueId,
          HoursOfOperationId: body.hoursOfOperationId
        };
        await connect.updateQueueHoursOfOperation(params).promise();
        updateResponses.push('Hours of Operation updated');
      }

      // Update outbound caller config
      if (body.outboundCallerConfig && 
          (body.outboundCallerConfig.OutboundCallerIdName !== undefined || 
           body.outboundCallerConfig.OutboundCallerIdNumberId !== undefined || 
           body.outboundCallerConfig.OutboundFlowId !== undefined)) {
        
        const currentOutboundCallerConfig = body.currentOutboundCallerConfig || {}; 
        
        const params = {
          InstanceId: instanceId,
          QueueId: queueId,
          OutboundCallerConfig: {
            OutboundCallerIdName: body.outboundCallerConfig.OutboundCallerIdName || currentOutboundCallerConfig.OutboundCallerIdName || '',
            OutboundCallerIdNumberId: body.outboundCallerConfig.OutboundCallerIdNumberId || currentOutboundCallerConfig.OutboundCallerIdNumberId || '',
            OutboundFlowId: body.outboundCallerConfig.OutboundFlowId || currentOutboundCallerConfig.OutboundFlowId || ''
          }
        };
        await connect.updateQueueOutboundCallerConfig(params).promise();
        updateResponses.push('Outbound caller config updated');
      }

      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Queue updated successfully', updates: updateResponses })
      };
    } catch (err) {
      console.error('Update failed:', err);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message })
      };
    }
  }

  // --- GET SINGLE QUEUE DETAILS --- (Updated Section)
  if (body.action === 'getDetails' && body.queueId) {
    try {
      const queueId = body.queueId;

      const describeQueue = await connect.describeQueue({
        InstanceId: instanceId,
        QueueId: queueId
      }).promise();
      // --- ADD THESE NEW DEBUG LINES ---
      console.log('DEBUG_LAMBDA: Raw describeQueue response:', JSON.stringify(describeQueue, null, 2));
      const queue = describeQueue.Queue; 
      console.log('DEBUG_LAMBDA: Extracted Queue object (describeQueue.Queue):', JSON.stringify(queue, null, 2));

      const listHoursOfOperationResult = await connect.listHoursOfOperations({
        InstanceId: instanceId
      }).promise();
      const availableHoursOfOperation = listHoursOfOperationResult.HoursOfOperationSummaryList.map(h => ({
        label: h.Name,
        value: h.Id
      }));

      const listPhoneNumbersResult = await connect.listPhoneNumbers({
        InstanceId: instanceId
      }).promise();
      const availableOutboundCallerIds = listPhoneNumbersResult.PhoneNumberSummaryList.map(p => ({
        label: p.PhoneNumber,
        value: p.Id
      }));

      const listFlowsResult = await connect.listContactFlows({
        InstanceId: instanceId,
        ContactFlowTypes: ['OUTBOUND_WHISPER'] 
      }).promise();
      const availableOutboundFlows = listFlowsResult.ContactFlowSummaryList.map(f => ({
        label: f.Name,
        value: f.Id
      }));

      // Find the names/numbers for the currently selected IDs, safely handling nulls
      const currentHoursOfOperationName = availableHoursOfOperation.find(h => h.value === queue.HoursOfOperationId)?.label || '';
      const currentOutboundCallerIdNumber = availableOutboundCallerIds.find(p => p.value === queue.OutboundCallerConfig?.OutboundCallerIdNumberId)?.label || '';
      const currentOutboundFlowName = availableOutboundFlows.find(f => f.value === queue.OutboundCallerConfig?.OutboundFlowId)?.label || '';

      // Construct the response object, ensuring all expected fields are explicitly set,
      // even if their source values are null or undefined, so they are included in the JSON.
      const responseData = {
          // Explicitly include ID, even if queue.Id might be null (though it shouldn't be here)
          id: queue.QueueId || null, 
          name: queue.Name || null,
          description: queue.Description || '',
          status: queue.Status || null,
          
          // Ensure these IDs are explicitly present in the response
          hoursOfOperationId: queue.HoursOfOperationId || null, 
          outboundCallerIdNumberId: queue.OutboundCallerConfig?.OutboundCallerIdNumberId || null, 
          outboundFlowId: queue.OutboundCallerConfig?.OutboundFlowId || null, 
          
          // Display names/numbers
          hoursOfOperationName: currentHoursOfOperationName,
          outboundCallerIdNumber: currentOutboundCallerIdNumber,
          outboundFlowName: currentOutboundFlowName,

          // All available options for picklists
          availableHoursOfOperation: availableHoursOfOperation,
          availableOutboundCallerIds: availableOutboundCallerIds,
          availableOutboundFlows: availableOutboundFlows
      };

      return {
        statusCode: 200,
        body: JSON.stringify(responseData) // Stringify the explicitly constructed object
      };

    } catch (err) {
      console.error('Get queue details failed:', err);
      // Log the specific queueId that was attempted for better debugging
      console.error('Failed queueId:', body.queueId); 
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message, queueId: body.queueId }) // Include queueId in error response
      };
    }
  }

  // --- DEFAULT: LIST QUEUES ---
  try {
    const result = await connect.listQueues({
      InstanceId: instanceId,
      MaxResults: 100
    }).promise();

    const queueDetails = await Promise.all(result.QueueSummaryList.map(async (queue) => {
      try {
        const describe = await connect.describeQueue({
          InstanceId: instanceId,
          QueueId: queue.Id
        }).promise();

        return {
          id: queue.Id,
          name: queue.Name,
          description: describe.Queue.Description || '',
          status: describe.Queue.Status
        };
      } catch (e) {
        return {
          id: queue.Id,
          name: queue.Name,
          description: '',
          status: 'Unknown',
          error: e.message
        };
      }
    }));

    return {
      statusCode: 200,
      body: JSON.stringify({ queues: queueDetails })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }) 
    };
  }
};