const AWS = require('aws-sdk');
const connect = new AWS.Connect();

const createResponse = (statusCode, body) => {
    return {
        statusCode,
        headers: {
            "Content-Type": "application/json",
            // Add CORS headers to allow requests from any origin (like Salesforce)
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST, OPTIONS"
        },
        body: JSON.stringify(body),
    };
};

exports.handler = async (event) => {
    // Log the entire incoming event for easier debugging
    console.log('Received event:', JSON.stringify(event, null, 2));

    // --- MAIN UPDATE IS HERE ---
    // For HTTP calls via Function URL, the data is in event.body as a string.
    // For test events from the console, the data is the event itself.
    // This line handles both cases correctly.
    const requestData = typeof event.body === 'string' ? JSON.parse(event.body) : event;
    
    // Now, get the action and payload from the parsed data
    const { action, payload = {} } = requestData;
    
    const instanceId = process.env.INSTANCE_ID;

    // The "getTimezones" action does not require an instanceId
    if (!instanceId && action !== 'getTimezones') {
        return createResponse(500, { error: "INSTANCE_ID environment variable is not set." });
    }

    try {
        switch (action) {
            case "list":
                return await getAllHoursOfOperation(instanceId);
            case "create":
                return await createHoursOfOperation(instanceId, payload);
            case "delete":
                return await deleteHoursOfOperation(instanceId, payload);
            case "update":
                return await updateHoursOfOperation(instanceId, payload);
            case "getTimezones":
                return getTimezones();
            default:
                // Use the received action in the error message for better diagnostics
                return createResponse(400, { error: `Invalid action: '${action}'. Must be one of 'list', 'create', 'delete', 'update', 'getTimezones'.` });
        }
    } catch (e) {
        console.error(e);
        const error = {
            error: e.name || "Error",
            message: e.message || "An unexpected error occurred."
        };
        const statusCode = e.name === 'ResourceNotFoundException' ? 404 : 500;
        return createResponse(statusCode, error);
    }
};

const getAllHoursOfOperation = async (instanceId) => {
    const allDetails = [];
    let nextToken;
    do {
        const listResponse = await connect.listHoursOfOperations({ InstanceId: instanceId, NextToken: nextToken }).promise();
        if (listResponse.HoursOfOperationSummaryList) {
            for (const hooSummary of listResponse.HoursOfOperationSummaryList) {
                const details = await connect.describeHoursOfOperation({ InstanceId: instanceId, HoursOfOperationId: hooSummary.Id }).promise();
                allDetails.push(details.HoursOfOperation);
            }
        }
        nextToken = listResponse.NextToken;
    } while (nextToken);
    return createResponse(200, allDetails);
};

const createHoursOfOperation = async (instanceId, payload) => {
    const { name, time_zone, config, description = '' } = payload;
    if (!name || !time_zone || !config) {
        return createResponse(400, { error: "Payload must include: name, time_zone, config" });
    }
    const response = await connect.createHoursOfOperation({ InstanceId: instanceId, Name: name, Description: description, TimeZone: time_zone, Config: config }).promise();
    return createResponse(201, { message: 'Hours of Operation created successfully.', Id: response.HoursOfOperationId, Arn: response.HoursOfOperationArn });
};

const deleteHoursOfOperation = async (instanceId, payload) => {
    const { hours_of_operation_id: hooId } = payload;
    if (!hooId) { return createResponse(400, { error: "Payload must include hours_of_operation_id" }); }
    await connect.deleteHoursOfOperation({ InstanceId: instanceId, HoursOfOperationId: hooId }).promise();
    return createResponse(200, { message: `Hours of Operation '${hooId}' deleted successfully.` });
};

const updateHoursOfOperation = async (instanceId, payload) => {
    const { hours_of_operation_id: hooId, ...updateFields } = payload;
    if (!hooId) { return createResponse(400, { error: "Payload must include hours_of_operation_id" }); }
    const updateParams = { InstanceId: instanceId, HoursOfOperationId: hooId };
    if (updateFields.name) updateParams.Name = updateFields.name;
    if (updateFields.description) updateParams.Description = updateFields.description;
    if (updateFields.time_zone) updateParams.TimeZone = updateFields.time_zone;
    if (updateFields.config) updateParams.Config = updateFields.config;
    if (Object.keys(updateParams).length <= 2) { return createResponse(400, { error: "No updateable fields provided." }); }
    await connect.updateHoursOfOperation(updateParams).promise();
    return createResponse(200, { message: `Hours of Operation '${hooId}' updated successfully.` });
};

const getTimezones = () => {
    try {
        const timezones = Intl.supportedValuesOf('timeZone');
        timezones.sort();
        return createResponse(200, timezones);
    } catch (e) {
        console.error(e);
        return createResponse(500, { error: "Failed to retrieve timezones." });
    }
};