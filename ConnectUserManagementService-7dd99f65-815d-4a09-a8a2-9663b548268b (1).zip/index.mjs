import { 
    ConnectClient, 
    ListUsersCommand, 
    DescribeUserCommand, 
    CreateUserCommand, 
    DeleteUserCommand, 
    ListRoutingProfilesCommand, 
    ListSecurityProfilesCommand,
    UpdateUserRoutingProfileCommand,
    UpdateUserSecurityProfilesCommand
} from "@aws-sdk/client-connect";

// ⚠️ IMPORTANT: Set this Instance ID as an Environment Variable in your Lambda configuration
const instanceId = process.env.INSTANCE_ID; 

// Initialize the V3 Connect Client
const connectClient = new ConnectClient({}); 

// Helper function to parse event body
const parseBody = (event) => {
    let body;
    if (event.body) {
        try {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } catch (e) {
            console.error("Error parsing JSON body:", e);
            throw new Error('Invalid JSON format in request body');
        }
    } else {
        body = event;
    }
    return body;
};

/**
 * Fetches all Routing and Security Profiles and returns ID-to-Name maps.
 */
const getProfileMaps = async () => {
    const routingProfileMap = new Map();
    const securityProfileMap = new Map();

    // Fetch Routing Profiles
    const rpResult = await connectClient.send(new ListRoutingProfilesCommand({ 
        InstanceId: instanceId, 
        MaxResults: 100 
    }));
    for (const p of rpResult.RoutingProfileSummaryList) {
        routingProfileMap.set(p.Id, p.Name);
    }

    // Fetch Security Profiles
    const spResult = await connectClient.send(new ListSecurityProfilesCommand({ 
        InstanceId: instanceId, 
        MaxResults: 100 
    }));
    for (const s of spResult.SecurityProfileSummaryList) {
        securityProfileMap.set(s.Id, s.Name);
    }

    return { routingProfileMap, securityProfileMap };
};


/**
 * Helper to handle Connect response flattening and ID-to-Name lookup.
 * NOTE: This function now accepts the lookup maps.
 */
const processConnectUser = async (userSummary, profileMaps) => {
    try {
        const command = new DescribeUserCommand({
            InstanceId: instanceId,
            UserId: userSummary.Id
        });
        const userDetails = await connectClient.send(command);
        
        const user = userDetails.User;
        const securityProfileIds = user.SecurityProfileIds || [];
        
        // --- ID to Name Lookup Logic ---
        const routingProfileName = profileMaps.routingProfileMap.get(user.RoutingProfileId) || user.RoutingProfileId;
        
        const securityProfileNames = securityProfileIds
            .map(id => profileMaps.securityProfileMap.get(id) || id)
            .join(', ');
        // -------------------------------

        return {
            id: user.Id,
            arn: user.Arn,
            username: user.Username,
            
            // Pass IDs (for updates)
            routingProfileId: user.RoutingProfileId, 
            securityProfileIds: securityProfileIds, 
            
            // Pass Names (for display)
            routingProfileName: routingProfileName, 
            securityProfileNames: securityProfileNames || 'None',
            
            phoneType: user.PhoneConfig.PhoneType,
            deskPhoneNumber: user.PhoneConfig.DeskPhoneNumber,
            status: 'SUCCESS' 
        };
    } catch (e) {
        console.error(`Error describing user ${userSummary.Id}: ${e.message}`);
        return {
            id: userSummary.Id,
            username: userSummary.Username,
            status: 'ERROR',
            error: e.message
        };
    }
};

export async function handler(event) {
    let body;
    try {
        body = parseBody(event);
    } catch (e) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Failed to parse request body' }) };
    }

    const action = body.action;

    // ----------------------------------------------------
    // 📜 LIST Users (listUsers)
    // ----------------------------------------------------
    if (action === 'listUsers') {
        try {
            // 1. Fetch Name Mappings once
            const profileMaps = await getProfileMaps();
            
            // 2. Fetch User Summaries
            const listResult = await connectClient.send(new ListUsersCommand({ 
                InstanceId: instanceId,
                MaxResults: 100
            }));
            
            // 3. Process sequentially with lookup maps
            const users = [];
            for (const userSummary of listResult.UserSummaryList) {
                const userDetail = await processConnectUser(userSummary, profileMaps);
                users.push(userDetail);
            }

            return { statusCode: 200, body: JSON.stringify(users) };
        } catch (err) {
            console.error('listUsers error:', err);
            return { statusCode: 500, body: JSON.stringify({ error: 'Failed to list Connect users', details: err.message }) };
        }
    }
    
    // ----------------------------------------------------
    // 🔍 GET User Details (getUserDetails) - FOR UPDATE FORM
    // ----------------------------------------------------
    if (action === 'getUserDetails' && body.userId) {
        try {
            const command = new DescribeUserCommand({
                InstanceId: instanceId,
                UserId: body.userId
            });
            const userDetails = await connectClient.send(command);
            
            const user = userDetails.User;

            // Return minimal data needed to pre-populate the LWC update form
            return {
                statusCode: 200, 
                body: JSON.stringify({
                    id: user.Id,
                    username: user.Username,
                    routingProfileId: user.RoutingProfileId,
                    securityProfileIds: user.SecurityProfileIds || [], 
                    securityProfileNames: user.SecurityProfileIds ? user.SecurityProfileIds.join(', ') : 'None',
                })
            };

        } catch (err) {
            console.error('getUserDetails error:', err);
            return { statusCode: 500, body: JSON.stringify({ error: 'Failed to fetch user details', details: err.message }) };
        }
    }

    // ----------------------------------------------------
    // ✏️ UPDATE User Profiles (updateUserProfiles)
    // ----------------------------------------------------
    if (action === 'updateUserProfiles' && body.userId && body.routingProfileId && body.securityProfileIds) {
        const { userId, routingProfileId, securityProfileIds } = body;
        
        try {
            // 1. Update Routing Profile
            await connectClient.send(new UpdateUserRoutingProfileCommand({
                InstanceId: instanceId,
                UserId: userId,
                RoutingProfileId: routingProfileId
            }));
            
            // 2. Update Security Profiles
            await connectClient.send(new UpdateUserSecurityProfilesCommand({
                InstanceId: instanceId,
                UserId: userId,
                SecurityProfileIds: securityProfileIds
            }));

            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'User profiles updated successfully' })
            };
        } catch (err) {
            console.error('updateUserProfiles error:', err);
            return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
        }
    }


    // ----------------------------------------------------
    // ➕ CREATE User (createUser)
    // ----------------------------------------------------
    if (action === 'createUser' && body.username && body.routingProfileId && body.securityProfileIds) {
        const { username, firstName, lastName, email, routingProfileId, securityProfileIds, phoneType, deskPhoneNumber } = body;
        
        try {
            const params = {
                InstanceId: instanceId,
                Username: username,
                IdentityInfo: {
                    FirstName: firstName,
                    LastName: lastName,
                    ...(email && { Email: email }),
                },
                PhoneConfig: {
                    PhoneType: phoneType,
                    ...(phoneType === 'DESK_PHONE' && deskPhoneNumber && { DeskPhoneNumber: deskPhoneNumber }),
                    ...(phoneType === 'SOFT_PHONE' && { AutoAccept: true, AfterContactWorkTimeLimit: 0, Softphone: {} }),
                },
                RoutingProfileId: routingProfileId,
                SecurityProfileIds: securityProfileIds
            };

            const result = await connectClient.send(new CreateUserCommand(params));
            
            return {
                statusCode: 200,
                body: JSON.stringify({ message: `Connect Agent ${username} created.`, userId: result.UserId })
            };
        } catch (err) {
            console.error('createUser error:', err);
            return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
        }
    }

    // ----------------------------------------------------
    // 🗑️ DELETE User (deleteUser)
    // ----------------------------------------------------
    if (action === 'deleteUser' && body.userId) {
        try {
            await connectClient.send(new DeleteUserCommand({
                InstanceId: instanceId,
                UserId: body.userId
            }));

            return { statusCode: 200, body: JSON.stringify({ message: 'User deleted successfully' }) };
        } catch (err) {
            console.error('deleteUser error:', err);
            return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
        }
    }

    // ----------------------------------------------------
    // ⚙️ GET Options (getOptions)
    // ----------------------------------------------------
    if (action === 'getOptions') {
        try {
            // Reusing getProfileMaps logic, but formatting for LWC combobox options
            const { routingProfileMap, securityProfileMap } = await getProfileMaps();

            const routingProfiles = Array.from(routingProfileMap, ([id, name]) => ({
                label: name,
                value: id
            }));
            const securityProfiles = Array.from(securityProfileMap, ([id, name]) => ({
                label: name,
                value: id
            }));
            
            return {
                statusCode: 200,
                body: JSON.stringify({
                    RoutingProfiles: routingProfiles,
                    SecurityProfiles: securityProfiles
                })
            };

        } catch (err) {
            console.error('getOptions error:', err);
            return { statusCode: 500, body: JSON.stringify({ error: 'Failed to fetch options', details: err.message }) };
        }
    }

    // ----------------------------------------------------
    // ❌ Unknown action
    // ----------------------------------------------------
    return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Invalid or missing action parameter' })
    };
}