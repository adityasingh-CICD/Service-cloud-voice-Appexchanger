const AWS = require('aws-sdk');
const connect = new AWS.Connect();
const instanceId = process.env.INSTANCE_ID;

exports.handler = async (event) => {
  let body;

  // Parse incoming request
  try {
    console.log('🧾 Raw event:', JSON.stringify(event));
    if (event.body) {
      body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    } else {
      body = event;
    }
    console.log('📨 Parsed body:', JSON.stringify(body));
  } catch (e) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Failed to parse request', details: e.message }),
    };
  }

  const action = body.action;

  // 🗑️ DELETE
  if (action === 'deleteRoutingProfile' && body.routingProfileId) {
    try {
      await connect.deleteRoutingProfile({
        InstanceId: instanceId,
        RoutingProfileId: body.routingProfileId
      }).promise();

      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Routing profile deleted successfully' })
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message })
      };
    }
  }

  // ✏️ UPDATE
  if (action === 'updateRoutingProfile') {
    const profileId = body.routingProfileId || '';
    const name = body.name || '';
    const description = body.description || '';
    const defaultOutboundQueueId = body.defaultOutboundQueueId || '';
    const queueIds = Array.isArray(body.queueIds) ? body.queueIds : [];

    if (!profileId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing routingProfileId' })
      };
    }

    const updateResults = [];

    try {
      // Update name/description
      if (name || description) {
        await connect.updateRoutingProfileName({
          InstanceId: instanceId,
          RoutingProfileId: profileId,
          Name: name,
          Description: description
        }).promise();
        updateResults.push('Name/Description updated');
      }

      // Update default outbound queue
      if (defaultOutboundQueueId) {
        await connect.updateRoutingProfileDefaultOutboundQueue({
          InstanceId: instanceId,
          RoutingProfileId: profileId,
          DefaultOutboundQueueId: defaultOutboundQueueId
        }).promise();
        updateResults.push('DefaultOutboundQueue updated');
      }

      // Update queues
      if (queueIds.length > 0) {
        const queueConfigs = queueIds.map(queueId => ({
          QueueReference: {
            QueueId: queueId,
            Channel: 'VOICE'
          },
          Priority: 1,
          Delay: 0
        }));

        await connect.updateRoutingProfileQueues({
          InstanceId: instanceId,
          RoutingProfileId: profileId,
          QueueConfigs: queueConfigs
        }).promise();
        updateResults.push('Queues updated');
      }

      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Update successful', updates: updateResults })
      };

    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Update failed', details: err.message })
      };
    }
  }

  // 🔍 GET DETAILS
  if (action === 'getRoutingProfileDetails' && body.routingProfileId) {
    try {
      const describe = await connect.describeRoutingProfile({
        InstanceId: instanceId,
        RoutingProfileId: body.routingProfileId
      }).promise();

      const queueIdsInProfile = (describe.RoutingProfile.QueueConfigs || []).map(q => q.QueueReference.QueueId);

      const queuesResult = await connect.listQueues({
        InstanceId: instanceId,
        MaxResults: 100
      }).promise();

      const allQueues = queuesResult.QueueSummaryList.map(q => ({
        id: q.Id,
        name: q.Name
      }));

      // Add missing assigned queues
      const queueMap = new Map(allQueues.map(q => [q.id, q]));
      for (const qid of queueIdsInProfile) {
        if (!queueMap.has(qid)) {
          queueMap.set(qid, { id: qid, name: '[Assigned Queue]' });
        }
      }

      return {
        statusCode: 200,
        body: JSON.stringify({
          id: describe.RoutingProfile.Id,
          name: describe.RoutingProfile.Name,
          description: describe.RoutingProfile.Description || '',
          defaultOutboundQueueId: describe.RoutingProfile.DefaultOutboundQueueId,
          queueIds: queueIdsInProfile,
          availableQueues: Array.from(queueMap.values())
        })
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message })
      };
    }
  }

  // 📋 LIST Queues
  if (action === 'listQueues') {
    try {
      const result = await connect.listQueues({
        InstanceId: instanceId,
        MaxResults: 100
      }).promise();

      const queues = result.QueueSummaryList.map(q => ({
        id: q.Id,
        name: q.Name
      }));

      return {
        statusCode: 200,
        body: JSON.stringify({ queues })
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message })
      };
    }
  }

  // 📜 LIST Routing Profiles
  if (!action || action === 'listRoutingProfiles') {
    try {
      const result = await connect.listRoutingProfiles({
        InstanceId: instanceId,
        MaxResults: 100
      }).promise();

      const profileDetails = await Promise.all(result.RoutingProfileSummaryList.map(async (profile) => {
        try {
          const describe = await connect.describeRoutingProfile({
            InstanceId: instanceId,
            RoutingProfileId: profile.Id
          }).promise();

          return {
            id: profile.Id,
            name: profile.Name,
            description: describe.RoutingProfile.Description || '',
            defaultOutboundQueueId: describe.RoutingProfile.DefaultOutboundQueueId
          };
        } catch (e) {
          return {
            id: profile.Id,
            name: profile.Name,
            description: '',
            defaultOutboundQueueId: null,
            error: e.message
          };
        }
      }));

      return {
        statusCode: 200,
        body: JSON.stringify({ routingProfiles: profileDetails })
      };
    } catch (err) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: err.message })
      };
    }
  }

  // ❌ Unknown action
  return {
    statusCode: 400,
    body: JSON.stringify({ error: 'Invalid action' })
  };
};
