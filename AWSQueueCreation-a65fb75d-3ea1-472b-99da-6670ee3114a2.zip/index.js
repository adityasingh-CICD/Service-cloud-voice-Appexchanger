const AWS = require('aws-sdk');

exports.handler = async (event) => {
  const connect = new AWS.Connect();

  // Read InstanceId from environment variables
  const InstanceId = process.env.INSTANCE_ID;

  // ✅ Parse input payload correctly (for Lambda Function URL)
  let input;
  try {
    input = typeof event.body === 'string' ? JSON.parse(event.body) : event;
  } catch (err) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid JSON input" })
    };
  }

  // Destructure fields from parsed input
  const {
    QueueName,
    Description,
    HoursOfOperationId,
    OutboundCallerIdNumberId,
    OutboundFlowId
  } = input;

  // ✅ Validation checks
  if (!InstanceId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Environment variable INSTANCE_ID is missing" })
    };
  }

  if (!HoursOfOperationId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "HoursOfOperationId is required" })
    };
  }

  const params = {
    InstanceId,
    Name: QueueName,
    Description,
    HoursOfOperationId
  };

  if (OutboundCallerIdNumberId && OutboundFlowId) {
    params.OutboundCallerConfig = {
      OutboundCallerIdName: 'FromLambda',
      OutboundCallerIdNumberId,
      OutboundFlowId
    };
  }

  // ✅ Try creating queue
  try {
    const result = await connect.createQueue(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (err) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: err.message })
    };
  }
};
