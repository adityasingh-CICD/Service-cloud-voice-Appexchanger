const AWS = require('aws-sdk');
const connect = new AWS.Connect({ region: 'us-west-2' });

const INSTANCE_ID = '28ea12c9-3ea5-4164-ad13-d7c4d8296aa2';

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event));

    let action;
    let parsedBody;

    try {
        if (event.body) {
            parsedBody = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
            action = parsedBody.action;
        }
    } catch (err) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid JSON in body', error: err.message }),
            isBase64Encoded: false
        };
    }

    // ✅ LIST ROUTING PROFILES
    if (action === 'listRoutingProfiles') {
        try {
            const routingProfiles = await connect.listRoutingProfiles({ InstanceId: INSTANCE_ID }).promise();
            const allUsers = await getAllUsersWithProfile(INSTANCE_ID);

            const result = await Promise.all(routingProfiles.RoutingProfileSummaryList.map(async (profile) => {
                const profileDetails = await connect.describeRoutingProfile({
                    InstanceId: INSTANCE_ID,
                    RoutingProfileId: profile.Id
                }).promise();

                const queues = await connect.listRoutingProfileQueues({
                    InstanceId: INSTANCE_ID,
                    RoutingProfileId: profile.Id
                }).promise();

                const tags = await connect.listTagsForResource({
                    resourceArn: profile.Arn
                }).promise();

                const agentCount = allUsers.filter(user => user.RoutingProfileId === profile.Id).length;

                return {
                    Id: profile.Id,
                    Arn: profile.Arn,
                    Name: profile.Name,
                    LastModifiedTime: profileDetails.RoutingProfile.LastModifiedTime,
                    Description: profileDetails.RoutingProfile.Description || '',
                    QueueCount: new Set(queues.RoutingProfileQueueConfigSummaryList?.map(q => q.QueueArn)).size || 0,
                    NumberOfAgentsStaffed: agentCount,
                    Tags: tags.Tags || {}
                };
            }));

            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify(result),
                isBase64Encoded: false
            };

        } catch (err) {
            console.error('Error fetching routing profiles:', err);
            return {
                statusCode: 500,
                body: JSON.stringify({ message: 'Error fetching routing profiles', error: err.message }),
                isBase64Encoded: false
            };
        }

    // ✅ DESCRIBE ROUTING PROFILE
    } else if (action === 'describeRoutingProfile') {
        const routingProfileId = parsedBody.routingProfileId;

        if (!routingProfileId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing routingProfileId' }),
                isBase64Encoded: false
            };
        }

        try {
            const profileDetails = await connect.describeRoutingProfile({
                InstanceId: INSTANCE_ID,
                RoutingProfileId: routingProfileId
            }).promise();

            const queues = await connect.listRoutingProfileQueues({
                InstanceId: INSTANCE_ID,
                RoutingProfileId: routingProfileId
            }).promise();

            const sts = new AWS.STS();
            const accountInfo = await sts.getCallerIdentity().promise();
            const AWS_ACCOUNT_ID = accountInfo.Account;

            const constructedArn = `arn:aws:connect:us-west-2:${AWS_ACCOUNT_ID}:instance/${INSTANCE_ID}/routing-profile/${routingProfileId}`;


            const tags = await connect.listTagsForResource({
                resourceArn: constructedArn
            }).promise();

            const allUsers = await getAllUsersWithProfile(INSTANCE_ID);
            const agentCount = allUsers.filter(user => user.RoutingProfileId === routingProfileId).length;

            const result = {
                Id: routingProfileId,
                Arn: constructedArn,
                Name: profileDetails.RoutingProfile.Name,
                LastModifiedTime: profileDetails.RoutingProfile.LastModifiedTime,
                Description: profileDetails.RoutingProfile.Description || '',
                QueueCount: new Set(queues.RoutingProfileQueueConfigSummaryList?.map(q => q.QueueArn)).size || 0,
                NumberOfAgentsStaffed: agentCount,
                Tags: tags.Tags || {}
            };

            return {
                statusCode: 200,
                body: JSON.stringify(result),
                isBase64Encoded: false
            };

        } catch (err) {
            console.error('Error describing routing profile:', err);
            return {
                statusCode: 500,
                body: JSON.stringify({ message: 'Error describing routing profile', error: err.message }),
                isBase64Encoded: false
            };
        }
        // ✅ DELETE ROUTING PROFILE
    } else if (action === 'deleteRoutingProfile') {
        const { routingProfileId } = parsedBody;

        if (!routingProfileId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing routingProfileId' }),
                isBase64Encoded: false
            };
        }

        try {
            await connect.deleteRoutingProfile({
                InstanceId: INSTANCE_ID,
                RoutingProfileId: routingProfileId
            }).promise();

            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Routing profile deleted successfully' }),
                isBase64Encoded: false
            };
        } catch (err) {
            console.error('Error deleting routing profile:', err);
            return {
                statusCode: 500,
                body: JSON.stringify({ message: 'Error deleting routing profile', error: err.message }),
                isBase64Encoded: false
            };
        }

    // ✅ CREATE ROUTING PROFILE
    } else if (action === 'createRoutingProfile') {
        const { name, description, queueIds, defaultOutboundQueueId } = parsedBody;

        if (!name || !description || !Array.isArray(queueIds) || !defaultOutboundQueueId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing required parameters: name, description, queueIds, defaultOutboundQueueId' }),
                isBase64Encoded: false
            };
        }

        try {
            const createResp = await connect.createRoutingProfile({
                InstanceId: INSTANCE_ID,
                Name: name,
                Description: description,
                DefaultOutboundQueueId: defaultOutboundQueueId,
                MediaConcurrencies: [
                    { Channel: 'VOICE', Concurrency: 1 }
                ],
                QueueConfigs: queueIds.map(queueId => ({
                    QueueReference: {
                        QueueId: queueId,
                        Channel: 'VOICE' // 🟢 Required inside QueueReference
                    },
                    Priority: 1,
                    Delay: 0
                }))
            }).promise();

            return {
                statusCode: 200,
                body: JSON.stringify({
                    message: 'Routing profile created successfully',
                    routingProfileId: createResp.RoutingProfileId
                }),
                isBase64Encoded: false
            };
        } catch (err) {
            console.error('Error creating routing profile:', err);
            return {
                statusCode: 500,
                body: JSON.stringify({ message: 'Error creating routing profile', error: err.message }),
                isBase64Encoded: false
            };
        }

    // ❌ UNKNOWN ACTION
    } else {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Invalid action' }),
            isBase64Encoded: false
        };
    }
};

// 🔁 Helper to get all users and their routing profiles
async function getAllUsersWithProfile(instanceId) {
    let users = [];
    let nextToken;

    do {
        const listParams = {
            InstanceId: instanceId,
            NextToken: nextToken
        };

        const listResp = await connect.listUsers(listParams).promise();
        const summaries = listResp.UserSummaryList;

        const detailedUsers = await Promise.all(
            summaries.map(async (user) => {
                const desc = await connect.describeUser({
                    InstanceId: instanceId,
                    UserId: user.Id
                }).promise();

                return {
                    Id: user.Id,
                    RoutingProfileId: desc.User.RoutingProfileId
                };
            })
        );

        users = users.concat(detailedUsers);
        nextToken = listResp.NextToken;
    } while (nextToken);

    return users;
}