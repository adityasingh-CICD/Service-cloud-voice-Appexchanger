const AWS = require('aws-sdk');

exports.handler = async (event) => {
  const connect = new AWS.Connect();
  const instanceId = '28ea12c9-3ea5-4164-ad13-d7c4d8296aa2'; // replace if needed

  console.log("🔄 Starting to fetch queues...");

  // Pagination helper
  const paginate = async (fn, params, resultKey) => {
    let results = [];
    let nextToken;

    do {
      const response = await fn({ ...params, NextToken: nextToken }).promise();
      results = results.concat(response[resultKey] || []);
      nextToken = response.NextToken;
      console.log(`Fetched ${resultKey} batch, total so far: ${results.length}`);
    } while (nextToken);

    return results;
  };

  try {
    console.log("📦 Fetching Queue Summary List...");
    const queueSummaries = await paginate(
      connect.listQueues.bind(connect),
      { InstanceId: instanceId, MaxResults: 100 },
      'QueueSummaryList'
    );

    console.log("🔍 Fetching queue details...");
    const queueDetails = await Promise.all(queueSummaries.map(async (queue) => {
      try {
        const describe = await connect.describeQueue({
          InstanceId: instanceId,
          QueueId: queue.Id
        }).promise();

        return {
          id: queue.Id,
          name: queue.Name,
          description: describe.Queue.Description || '',
          status: describe.Queue.Status
        };
      } catch (err) {
        console.error(`❌ Failed to describe queue ${queue.Id}:`, err.message);
        return {
          id: queue.Id,
          name: queue.Name,
          error: err.message
        };
      }
    }));

    return {
      statusCode: 200,
      body: JSON.stringify({ queues: queueDetails })
    };
  } catch (err) {
    console.error("❌ Error fetching queues:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
