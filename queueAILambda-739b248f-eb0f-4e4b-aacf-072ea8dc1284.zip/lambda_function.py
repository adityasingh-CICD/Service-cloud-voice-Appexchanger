import boto3
import json
import google.generativeai as genai

# Environment configuration
s3_bucket_name = 'my-queue-bucket-for-ai'
s3_key = 'queue.json'

# Gemini API key setup
genai.configure(api_key="AIzaSyBlI_xv7b3vV84IQh8rTD-3BBOZ66ZdvSw")  # Replace with your actual API key

# Initialize S3 client
s3 = boto3.client('s3')

# Use Gemini Pro model
model = genai.GenerativeModel('gemini-pro')

def get_gemini_match(prompt, queue_list):
    """
    Uses the Gemini API to find the best matching queue from a list,
    based on natural language understanding of the customer prompt.

    Args:
        prompt (str): The customer's request (transcript).
        queue_list (list): A list of queue dictionaries from the S3 file.

    Returns:
        dict: A dictionary representing the matched queue, or a "No Match Found"
              or "Error" dictionary.
    """
    try:
        # Build prompt
        full_prompt = f"""
You are a contact center routing assistant. Your task is to analyze customer requests and determine the most appropriate queue.

Here is the data for the available queues, in JSON format:
{json.dumps(queue_list, indent=2)}

The customer is asking the following: "{prompt}"

Identify the single queue from the list that is the *most relevant* to the customer's request. Consider the meaning and intent of the request, not just keyword matching.  Respond *only* with the complete JSON object for that queue.

For example, if the customer asks "I need to pay my bill", you should respond with:
{json.dumps(queue_list[0], indent=2)}  (Assuming the first item is the billing queue)

If *none* of the queues are a good match, respond *EXACTLY* with the following JSON:
{{
  "name": "No Match Found",
  "arn": "N/A",
  "description": "No matching queue found for your request."
}}
"""
        response = model.generate_content(full_prompt)
        response_text = response.text.strip()

        # Try parsing JSON from Gemini output
        try:
            match = json.loads(response_text)
            return match
        except json.JSONDecodeError:
            # Handle cases where Gemini doesn't return valid JSON
            print(f"Gemini output was not valid JSON.  Prompt: '{prompt}'. Response: '{response_text}'")
            return {
                "name": "No Match Found",
                "arn": "N/A",
                "description": f"Error: Could not understand Gemini's response.  Please check the prompt and Gemini's output. Response was: '{response_text}'"
            }

    except Exception as e:
        # Handle errors during the Gemini API call
        print(f"Error calling Gemini API. Prompt: '{prompt}'. Error: {e}")
        return {
            "name": "Error",
            "arn": "N/A",
            "description": f"Error: {e}"
        }


def lambda_handler(event, context):
    """
    AWS Lambda function handler.  Retrieves the customer query from the event,
    fetches the queue list from S3, uses Gemini to find the matching queue,
    and returns the result.

    Args:
        event (dict): The AWS Lambda event payload.  Expected to contain
                      a 'input' key with the customer query.
        context (object): The AWS Lambda context object (not used here).

    Returns:
        dict: A dictionary with the HTTP status code and the response body
              (JSON string) containing the matched queue information.
    """
    try:
        user_query = event.get('input')  # Get the input from the event
        if not user_query:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing input query (transcript).'}),
            }

        # Load queue list from S3
        try:
            obj = s3.get_object(Bucket=s3_bucket_name, Key=s3_key)
            file_content = obj['Body'].read().decode('utf-8')
            queue_list = json.loads(file_content)
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({'error': f"Error loading queue data from S3: {e}"}),
            }

        # Call Gemini to find best match
        gemini_response = get_gemini_match(user_query, queue_list)

        return {
            'statusCode': 200,
            'body': json.dumps(gemini_response, ensure_ascii=False),
        }

    except Exception as e:
        # Handle any unexpected errors
        print(f"Unhandled error in lambda_handler: {e}")  # Log for debugging
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f"Internal server error: {e}"}),
        }
